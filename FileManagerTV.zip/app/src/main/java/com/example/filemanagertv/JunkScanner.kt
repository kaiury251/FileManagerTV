package com.example.filemanagertv

import android.os.Build
import android.os.Environment
import androidx.annotation.StringRes
import java.io.File

enum class JunkType(@StringRes val title: Int, @StringRes val desc: Int) {
    CACHE(R.string.junk_cache, R.string.junk_cache_desc),
    TEMP(R.string.junk_temp, R.string.junk_temp_desc),
    THUMBS(R.string.junk_thumbs, R.string.junk_thumbs_desc),
    APKS(R.string.junk_apks, R.string.junk_apks_desc),
    EMPTY(R.string.junk_empty, R.string.junk_empty_desc),
    TRASH(R.string.junk_trash, R.string.junk_trash_desc)
}

/** Pasta usada como lixeira quando o usuário exclui sem marcar "permanentemente". */
object Trash {
    fun dir(): File = File(Environment.getExternalStorageDirectory(), ".FileManagerTV-Lixeira")
}

class JunkGroup(val type: JunkType) {
    val files = mutableListOf<File>()
    val itemSizes = HashMap<File, Long>()
    var size = 0L
    // APKs começam desmarcados: podem ser instaladores que o usuário ainda quer usar
    var checked = type != JunkType.APKS
}

/** Bytes usados por tipo de mídia (para a barra de armazenamento). */
class StorageBreakdown {
    var images = 0L
    var audio = 0L
    var video = 0L
    var apps = 0L
}

class ScanResult(
    val groups: List<JunkGroup>,
    val otherAppsCacheBlocked: Boolean,
    val breakdown: StorageBreakdown
)

object JunkScanner {

    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")
    private val AUDIO_EXT = setOf("mp3", "m4a", "aac", "wav", "flac", "ogg", "opus", "wma", "amr")
    private val VIDEO_EXT = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v", "wmv", "flv", "mpg", "mpeg")
    private val TEMP_EXT = setOf("tmp", "temp", "log", "chk", "crdownload", "part", "partial", "download")

    /** Varre o armazenamento e agrupa o que pode ser limpo. Rodar fora da thread principal. */
    fun scan(root: File, ownCaches: List<File>, appsBytes: Long): ScanResult {
        val breakdown = StorageBreakdown().also { it.apps = appsBytes }
        val groups = JunkType.values().associateWith { JunkGroup(it) }

        // ---- Cache (sem duplicar o mesmo diretório) ----
        val seen = HashSet<String>()
        val cacheFiles = groups.getValue(JunkType.CACHE).files
        fun addCache(dir: File) {
            val key = try { dir.canonicalPath } catch (e: Exception) { dir.absolutePath }
            if (dir.isDirectory && !dir.list().isNullOrEmpty() && seen.add(key)) cacheFiles.add(dir)
        }
        ownCaches.forEach { addCache(it) }

        val appDirs = File(root, "Android/data").listFiles()
        appDirs?.forEach { addCache(File(it, "cache")) }
        // A partir do Android 11 o acesso a Android/data é restrito
        val blocked = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R || appDirs == null

        // ---- Temporários, APKs, miniaturas, lixeira ----
        val androidDir = File(root, "Android")
        val trashPath = Trash.dir().absolutePath
        root.walkTopDown()
            .onEnter { dir ->
                when {
                    dir == androidDir -> false
                    dir.absolutePath == trashPath -> {
                        if (!dir.list().isNullOrEmpty()) groups.getValue(JunkType.TRASH).files.add(dir)
                        false
                    }
                    dir.name == ".thumbnails" -> {
                        if (!dir.list().isNullOrEmpty()) groups.getValue(JunkType.THUMBS).files.add(dir)
                        false
                    }
                    else -> true
                }
            }
            .filter { it.isFile }
            .forEach { f ->
                val ext = f.extension.lowercase()
                when (ext) {
                    in IMAGE_EXT -> breakdown.images += f.length()
                    in AUDIO_EXT -> breakdown.audio += f.length()
                    in VIDEO_EXT -> breakdown.video += f.length()
                }
                when {
                    ext == "apk" -> groups.getValue(JunkType.APKS).files.add(f)
                    ext in TEMP_EXT -> groups.getValue(JunkType.TEMP).files.add(f)
                }
            }

        // ---- Pastas vazias (inclui pastas que só têm subpastas vazias) ----
        // Pastas da raiz (DCIM, Download, Music...), ocultas, Android e lixeira nunca são listadas.
        val skip = { d: File -> d == androidDir || d.absolutePath == trashPath || d.name.startsWith(".") }
        val emptyFiles = groups.getValue(JunkType.EMPTY).files
        root.listFiles()?.filter { it.isDirectory && !skip(it) }?.forEach { collectEmpty(it, skip, emptyFiles) }

        // ---- Tamanhos ----
        groups.values.forEach { g ->
            g.files.forEach { f -> g.itemSizes[f] = sizeOf(f) }
            g.size = g.itemSizes.values.sum()
        }

        return ScanResult(groups.values.filter { it.files.isNotEmpty() }, blocked, breakdown)
    }

    private fun isEmptyTree(dir: File, skip: (File) -> Boolean): Boolean {
        val children = dir.listFiles() ?: return false
        return children.all { it.isDirectory && !skip(it) && isEmptyTree(it, skip) }
    }

    private fun collectEmpty(dir: File, skip: (File) -> Boolean, out: MutableList<File>) {
        dir.listFiles()?.filter { it.isDirectory && !skip(it) }?.forEach { c ->
            if (isEmptyTree(c, skip)) out.add(c) else collectEmpty(c, skip, out)
        }
    }

    fun delete(group: JunkGroup): Long {
        var freed = 0L
        group.files.forEach { f ->
            val s = group.itemSizes[f] ?: 0L
            val ok = if (group.type == JunkType.CACHE || group.type == JunkType.TRASH) {
                // Cache/lixeira: apaga o conteúdo e mantém a pasta
                f.listFiles()?.map { it.deleteRecursively() }?.all { it } ?: true
            } else f.deleteRecursively()
            if (ok) freed += s
        }
        return freed
    }

    fun sizeOf(f: File): Long =
        if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
}

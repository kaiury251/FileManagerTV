package com.example.filemanagertv

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors

class FileBrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_TITLE = "title"
        const val EXTRA_APPS = "apps"
        private const val GRID_SPANS = 3
    }

    private lateinit var recycler: RecyclerView
    private lateinit var layoutManager: GridLayoutManager
    private lateinit var pathText: TextView
    private lateinit var emptyText: TextView
    private lateinit var toggleButton: Button
    private lateinit var upButton: Button
    private lateinit var moveBar: View
    private lateinit var moveText: TextView
    private lateinit var moveHereButton: Button
    private lateinit var moveCancelButton: Button
    private lateinit var adapter: FileAdapter

    private val executor = Executors.newSingleThreadExecutor()
    private var rootDir: File? = null
    private var currentDir: File? = null
    private var gridMode = true

    // Modo "mover": guarda o item e a raiz original para restaurar depois
    private var movingFile: File? = null
    private var originalRoot: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_browser)

        recycler = findViewById(R.id.fileList)
        pathText = findViewById(R.id.pathText)
        emptyText = findViewById(R.id.emptyText)
        toggleButton = findViewById(R.id.toggleButton)
        upButton = findViewById(R.id.upButton)
        moveBar = findViewById(R.id.moveBar)
        moveText = findViewById(R.id.moveText)
        moveHereButton = findViewById(R.id.moveHereButton)
        moveCancelButton = findViewById(R.id.moveCancelButton)

        adapter = FileAdapter(onClick = { onItemClick(it) }, onLongClick = { onItemLongClick(it) })
        layoutManager = GridLayoutManager(this, GRID_SPANS)
        recycler.layoutManager = layoutManager
        recycler.adapter = adapter

        toggleButton.setOnClickListener { toggleMode() }
        upButton.setOnClickListener { goUp() }
        moveHereButton.setOnClickListener { confirmMove() }
        moveCancelButton.setOnClickListener { endMove() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    movingFile != null -> endMove()
                    !goUp() -> finish()
                }
            }
        })

        if (intent.getBooleanExtra(EXTRA_APPS, false)) {
            pathText.text = intent.getStringExtra(EXTRA_TITLE)
            upButton.visibility = View.GONE
            loadApps()
        } else {
            val path = intent.getStringExtra(EXTRA_PATH) ?: "/sdcard"
            rootDir = File(path).also { if (!it.exists()) it.mkdirs() }
            loadDir(rootDir!!)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun toggleMode() {
        gridMode = !gridMode
        layoutManager.spanCount = if (gridMode) GRID_SPANS else 1
        toggleButton.setText(if (gridMode) R.string.view_list else R.string.view_grid)
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun loadDir(dir: File) {
        currentDir = dir
        pathText.text = dir.absolutePath
        val files = dir.listFiles()?.sortedWith(
            compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()

        val items = files.map {
            FileItem(it.name, it.absolutePath, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified())
        }
        adapter.submitList(items) {
            emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            recycler.scrollToPosition(0)
            recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
        upButton.isEnabled = currentDir != rootDir
    }

    private fun reload() = currentDir?.let { loadDir(it) }

    private fun goUp(): Boolean {
        val cur = currentDir ?: return false
        val root = rootDir ?: return false
        if (cur == root) return false
        cur.parentFile?.let { loadDir(it); return true }
        return false
    }

    private fun loadApps() {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(launcher, 0))
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val items = all.map {
            FileItem(
                name = it.loadLabel(pm).toString(),
                path = it.activityInfo.packageName,
                isDirectory = false,
                isApp = true,
                appIcon = it.loadIcon(pm)
            )
        }
        adapter.submitList(items) {
            emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
    }

    private fun onItemClick(item: FileItem) {
        when {
            item.isApp -> {
                val launch = packageManager.getLeanbackLaunchIntentForPackage(item.path)
                    ?: packageManager.getLaunchIntentForPackage(item.path)
                if (launch != null) startActivity(launch)
            }
            item.isDirectory -> loadDir(File(item.path))
            movingFile != null -> Unit // no modo mover, arquivos não abrem
            else -> openFile(File(item.path))
        }
    }

    // ---------- Menu de opções (segurar OK) ----------

    private fun onItemLongClick(item: FileItem) {
        if (item.isApp || movingFile != null) return
        val file = File(item.path)
        val options = arrayOf(
            getString(R.string.opt_rename),
            getString(R.string.opt_move),
            getString(R.string.opt_delete)
        )
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showRename(file)
                    1 -> startMove(file)
                    2 -> confirmDelete(file)
                }
            }
            .show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Renomear ----------

    private fun showRename(file: File) {
        val input = EditText(this).apply {
            setText(file.name)
            setSelection(0, file.nameWithoutExtension.length)
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(box)
            .setPositiveButton(R.string.rename_ok) { _, _ ->
                val newName = input.text.toString().trim()
                when {
                    newName.isEmpty() || newName.contains('/') -> toast(R.string.rename_invalid)
                    newName == file.name -> Unit
                    else -> {
                        val dest = File(file.parentFile, newName)
                        when {
                            dest.exists() -> toast(R.string.name_exists)
                            file.renameTo(dest) -> { toast(R.string.rename_done); reload() }
                            else -> toast(R.string.rename_fail)
                        }
                    }
                }
            }
            .setNegativeButton(R.string.move_cancel, null)
            .show()
    }

    // ---------- Excluir ----------

    private fun confirmDelete(file: File) {
        val message = TextView(this).apply {
            text = getString(R.string.delete_message, file.name)
            textSize = 16f
        }
        val check = CheckBox(this).apply { setText(R.string.delete_permanent) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(message)
            addView(check)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setView(box)
            .setPositiveButton(R.string.delete_confirm) { _, _ -> deleteFile(file, check.isChecked) }
            .setNegativeButton(R.string.move_cancel, null)
            .show()
        // Foco inicial em "Cancelar" para evitar exclusão acidental
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).requestFocus()
    }

    private fun deleteFile(file: File, permanentChoice: Boolean) {
        val inTrash = file.absolutePath.startsWith(Trash.dir().absolutePath)
        val permanent = permanentChoice || inTrash
        executor.execute {
            val ok = if (permanent) file.deleteRecursively() else moveToTrash(file)
            runOnUiThread {
                toast(
                    when {
                        !ok -> R.string.delete_fail
                        permanent -> R.string.deleted_perm
                        else -> R.string.deleted_trash
                    }
                )
                reload()
            }
        }
    }

    private fun moveToTrash(file: File): Boolean {
        val trash = Trash.dir().also { it.mkdirs() }
        var dest = File(trash, file.name)
        if (dest.exists()) dest = File(trash, "${System.currentTimeMillis()}_${file.name}")
        return moveFile(file, dest)
    }

    private fun moveFile(src: File, dest: File): Boolean {
        if (src.renameTo(dest)) return true
        return try {
            src.copyRecursively(dest, overwrite = false) && src.deleteRecursively()
        } catch (e: Exception) {
            dest.deleteRecursively()
            false
        }
    }

    // ---------- Mover ----------

    private fun startMove(file: File) {
        movingFile = file
        originalRoot = rootDir
        rootDir = Environment.getExternalStorageDirectory() // permite navegar para qualquer pasta
        moveText.text = getString(R.string.moving, file.name)
        moveBar.visibility = View.VISIBLE
        reload()
        moveHereButton.requestFocus()
    }

    private fun endMove() {
        movingFile = null
        moveBar.visibility = View.GONE
        rootDir = originalRoot
        val root = rootDir
        val cur = currentDir
        if (root != null && cur != null && !cur.absolutePath.startsWith(root.absolutePath)) {
            loadDir(root)
        } else {
            reload()
        }
    }

    private fun confirmMove() {
        val src = movingFile ?: return
        val dir = currentDir ?: return
        val dest = File(dir, src.name)
        when {
            src.parentFile == dir -> toast(R.string.move_same_folder)
            dir == src || dir.absolutePath.startsWith(src.absolutePath + "/") -> toast(R.string.move_into_self)
            dest.exists() -> toast(R.string.name_exists)
            else -> executor.execute {
                val ok = moveFile(src, dest)
                runOnUiThread {
                    toast(if (ok) R.string.move_done else R.string.move_fail)
                    endMove()
                }
            }
        }
    }

    // ---------- Abrir arquivo ----------

    private fun openFile(file: File) {
        val ext = MimeTypeMap.getFileExtensionFromUrl(file.name).lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(view)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show()
        }
    }
}

package com.example.filemanagertv

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/** Barra horizontal segmentada, com cantos arredondados, para mostrar o uso do armazenamento. */
class StorageBarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    class Segment(val value: Long, val color: Int)

    private var segments: List<Segment> = emptyList()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()

    fun setSegments(list: List<Segment>) {
        segments = list
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w, h), h / 2, h / 2, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        val total = segments.sumOf { it.value }.coerceAtLeast(1L).toFloat()
        var x = 0f
        for (s in segments) {
            if (s.value <= 0L) continue
            val sw = w * (s.value.toFloat() / total)
            paint.color = s.color
            canvas.drawRect(x, 0f, x + sw, h, paint)
            x += sw
        }
        canvas.restore()
    }
}

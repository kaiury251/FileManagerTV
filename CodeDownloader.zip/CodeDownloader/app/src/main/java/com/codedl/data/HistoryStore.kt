package com.codedl.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(val code: String, val fileName: String, val path: String, val time: Long)

class HistoryStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)

    fun load(): List<HistoryItem> {
        val arr = JSONArray(prefs.getString("items", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            HistoryItem(o.getString("code"), o.getString("name"), o.getString("path"), o.getLong("time"))
        }
    }

    fun add(item: HistoryItem): List<HistoryItem> {
        val list = (listOf(item) + load().filter { it.path != item.path }).take(5)
        save(list); return list
    }

    fun remove(item: HistoryItem): List<HistoryItem> {
        val list = load().filter { it.path != item.path }
        save(list); return list
    }

    private fun save(list: List<HistoryItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("code", it.code).put("name", it.fileName).put("path", it.path).put("time", it.time))
        }
        prefs.edit().putString("items", arr.toString()).apply()
    }
}

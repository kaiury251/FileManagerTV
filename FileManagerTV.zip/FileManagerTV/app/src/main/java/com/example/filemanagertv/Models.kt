package com.example.filemanagertv

import android.graphics.drawable.Drawable
import androidx.annotation.DrawableRes
import androidx.annotation.StringRes

enum class CategoryType { STORAGE, DOWNLOADS, IMAGES, MUSIC, VIDEOS, APPS }

data class Category(
    val type: CategoryType,
    @StringRes val title: Int,
    @DrawableRes val icon: Int
)

/** Item exibido no navegador: arquivo, pasta ou aplicativo. */
data class FileItem(
    val name: String,
    val path: String,          // caminho do arquivo ou packageName (apps)
    val isDirectory: Boolean,
    val size: Long = 0L,
    val modified: Long = 0L,
    val isApp: Boolean = false,
    val appIcon: Drawable? = null
)

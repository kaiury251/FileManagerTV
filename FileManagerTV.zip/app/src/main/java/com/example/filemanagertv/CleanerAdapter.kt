package com.example.filemanagertv

import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CleanerAdapter(
    private val onChanged: () -> Unit,
    private val onDetails: (JunkGroup) -> Unit
) : RecyclerView.Adapter<CleanerAdapter.VH>() {

    private var groups: List<JunkGroup> = emptyList()

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val check: CheckBox = view.findViewById(R.id.junkCheck)
        val title: TextView = view.findViewById(R.id.junkTitle)
        val desc: TextView = view.findViewById(R.id.junkDesc)
        val size: TextView = view.findViewById(R.id.junkSize)
    }

    fun submit(list: List<JunkGroup>) {
        groups = list
        notifyDataSetChanged()
    }

    fun selectedBytes() = groups.filter { it.checked }.sumOf { it.size }
    fun selectedGroups() = groups.filter { it.checked && it.files.isNotEmpty() }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_junk, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val g = groups[position]
        val ctx = holder.itemView.context
        holder.title.setText(g.type.title)
        holder.desc.text = ctx.getString(g.type.desc)
        holder.size.text = Formatter.formatShortFileSize(ctx, g.size) + "  •  " +
                ctx.getString(R.string.junk_items, g.files.size)
        holder.check.isChecked = g.checked

        // OK/Enter alterna a seleção; segurar OK mostra os itens
        holder.itemView.setOnClickListener {
            g.checked = !g.checked
            holder.check.isChecked = g.checked
            onChanged()
        }
        holder.itemView.setOnLongClickListener { onDetails(g); true }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val s = if (hasFocus) 1.02f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(100).start()
        }
    }

    override fun getItemCount() = groups.size
}

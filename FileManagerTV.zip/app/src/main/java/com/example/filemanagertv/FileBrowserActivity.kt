package com.example.filemanagertv

import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInstaller
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class FileBrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_TITLE = "title"
        const val EXTRA_APPS = "apps"
    }

    /** Copiar/mover: itens aguardando a pasta de destino. */
    private class PendingOp(val files: List<File>, val move: Boolean)

    private lateinit var recycler: RecyclerView
    private lateinit var layoutManager: GridLayoutManager
    private lateinit var pathText: TextView
    private lateinit var emptyText: TextView
    private lateinit var toggleButton: Button
    private lateinit var upButton: Button
    private lateinit var moveBar: View
    private lateinit var moveText: TextView
    private lateinit var moveHereButton: Button
    private lateinit var moveCancelButton: Button
    private lateinit var selectionBar: View
    private lateinit var selCount: TextView
    private lateinit var adapter: FileAdapter

    private val executor = Executors.newSingleThreadExecutor()
    private var rootDir: File? = null
    private var currentDir: File? = null
    private var gridMode = true
    private var appsMode = false
    private var needsAppsRefresh = false

    private var pending: PendingOp? = null
    private var originalRoot: File? = null

    // Seleção múltipla
    private var selectionMode = false
    private val selected = LinkedHashSet<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_browser)

        recycler = findViewById(R.id.fileList)
        pathText = findViewById(R.id.pathText)
        emptyText = findViewById(R.id.emptyText)
        toggleButton = findViewById(R.id.toggleButton)
        upButton = findViewById(R.id.upButton)
        moveBar = findViewById(R.id.moveBar)
        moveText = findViewById(R.id.moveText)
        moveHereButton = findViewById(R.id.moveHereButton)
        moveCancelButton = findViewById(R.id.moveCancelButton)
        selectionBar = findViewById(R.id.selectionBar)
        selCount = findViewById(R.id.selCount)

        adapter = FileAdapter(
            onClick = { onItemClick(it) },
            onLongClick = { onItemLongClick(it) },
            isSelectionMode = { selectionMode },
            isSelected = { it.path in selected }
        )
        layoutManager = GridLayoutManager(this, gridSpans())
        recycler.layoutManager = layoutManager
        recycler.adapter = adapter
        // Sem animação de troca: mantém o foco do D-Pad ao marcar itens
        (recycler.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        toggleButton.setOnClickListener { toggleMode() }
        upButton.setOnClickListener { goUp() }
        moveHereButton.setOnClickListener { confirmPaste() }
        moveCancelButton.setOnClickListener { endPaste() }

        findViewById<Button>(R.id.selAll).setOnClickListener { selectAll() }
        findViewById<Button>(R.id.selCopy).setOnClickListener { withSelection { startPaste(it, false) } }
        findViewById<Button>(R.id.selMove).setOnClickListener { withSelection { startPaste(it, true) } }
        findViewById<Button>(R.id.selCompress).setOnClickListener { withSelection { showCompress(it) } }
        findViewById<Button>(R.id.selDelete).setOnClickListener { withSelection { confirmDelete(it) } }
        findViewById<Button>(R.id.selCancel).setOnClickListener { exitSelection() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    pending != null -> endPaste()
                    selectionMode -> exitSelection()
                    !goUp() -> finish()
                }
            }
        })

        if (intent.getBooleanExtra(EXTRA_APPS, false)) {
            appsMode = true
            pathText.text = intent.getStringExtra(EXTRA_TITLE)
            upButton.visibility = View.GONE
            loadApps()
        } else {
            val path = intent.getStringExtra(EXTRA_PATH) ?: "/sdcard"
            rootDir = File(path).also { if (!it.exists()) it.mkdirs() }
            loadDir(rootDir!!)
        }
    }

    override fun onResume() {
        super.onResume()
        // Atualiza a lista ao voltar da desinstalação / informações do app
        if (appsMode && needsAppsRefresh) {
            needsAppsRefresh = false
            loadApps()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdown()
    }

    private fun gridSpans() = Device.browserSpans(this)

    private fun focusFirst() {
        // Foco inicial só na TV (D-Pad); no celular evita destacar o primeiro item
        if (Device.isTv(this)) {
            recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        layoutManager.spanCount = if (gridMode) gridSpans() else 1
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toggleMode() {
        gridMode = !gridMode
        layoutManager.spanCount = if (gridMode) gridSpans() else 1
        toggleButton.setText(if (gridMode) R.string.view_list else R.string.view_grid)
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    // ---------- Listagem ----------

    private fun loadDir(dir: File) {
        currentDir = dir
        pathText.text = dir.absolutePath
        val files = dir.listFiles()?.sortedWith(
            compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()

        val items = files.map {
            FileItem(it.name, it.absolutePath, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified())
        }
        adapter.submitList(items) {
            emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            recycler.scrollToPosition(0)
            focusFirst()
        }
        upButton.isEnabled = currentDir != rootDir
    }

    private fun reload() = currentDir?.let { loadDir(it) }

    private fun goUp(): Boolean {
        val cur = currentDir ?: return false
        val root = rootDir ?: return false
        if (cur == root) return false
        cur.parentFile?.let { loadDir(it); return true }
        return false
    }

    private fun loadApps() {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(launcher, 0))
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val items = all.map {
            FileItem(
                name = it.loadLabel(pm).toString(),
                path = it.activityInfo.packageName,
                isDirectory = false,
                isApp = true,
                appIcon = it.loadIcon(pm)
            )
        }
        adapter.submitList(items) {
            emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            focusFirst()
        }
    }

    // ---------- Cliques ----------

    private fun onItemClick(item: FileItem) {
        if (item.isApp) {
            val launch = packageManager.getLeanbackLaunchIntentForPackage(item.path)
                ?: packageManager.getLaunchIntentForPackage(item.path)
            if (launch != null) startActivity(launch)
            return
        }
        if (selectionMode) {
            toggleSelect(item)
            return
        }
        val lower = item.name.lowercase()
        when {
            item.isDirectory -> loadDir(File(item.path))
            pending != null -> Unit // ao copiar/mover, arquivos não abrem
            lower.endsWith(".apk") -> toast(R.string.apk_hint)
            lower.endsWith(".zip") -> toast(R.string.zip_hint)
            else -> openFile(File(item.path))
        }
    }

    // ---------- Menu de opções (segurar OK / segurar o toque) ----------

    private fun onItemLongClick(item: FileItem) {
        if (item.isApp) { showAppOptions(item); return }
        if (pending != null) return
        if (selectionMode) { toggleSelect(item); return }

        val file = File(item.path)
        val lower = file.name.lowercase()
        val isApk = !file.isDirectory && lower.endsWith(".apk")
        val isZip = !file.isDirectory && (lower.endsWith(".zip") || isApk)

        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        fun add(res: Int, action: () -> Unit) { labels += getString(res); actions += action }

        add(R.string.opt_select) { enterSelection(file) }
        if (isApk) add(R.string.install_yes) { confirmInstall(file) }
        if (isZip) {
            add(R.string.opt_extract_here) { extractHere(file) }
            add(R.string.opt_extract_folder) { extractToFolder(file) }
        }
        add(R.string.opt_compress) { showCompress(listOf(file)) }
        add(R.string.opt_copy) { startPaste(listOf(file), false) }
        add(R.string.opt_move) { startPaste(listOf(file), true) }
        add(R.string.opt_rename) { showRename(file) }
        add(R.string.opt_delete) { confirmDelete(listOf(file)) }

        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    // ---------- Seleção múltipla ----------

    private fun enterSelection(first: File?) {
        selectionMode = true
        selected.clear()
        first?.let { selected.add(it.absolutePath) }
        selectionBar.visibility = View.VISIBLE
        updateSelectionUi()
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun exitSelection() {
        selectionMode = false
        selected.clear()
        selectionBar.visibility = View.GONE
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun toggleSelect(item: FileItem) {
        if (!selected.remove(item.path)) selected.add(item.path)
        updateSelectionUi()
        val index = adapter.currentList.indexOfFirst { it.path == item.path }
        if (index >= 0) adapter.notifyItemChanged(index)
    }

    private fun selectAll() {
        adapter.currentList.forEach { selected.add(it.path) }
        updateSelectionUi()
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun updateSelectionUi() {
        selCount.text = getString(R.string.selected_count, selected.size)
    }

    /** Executa [action] com os itens marcados e sai do modo de seleção. */
    private fun withSelection(action: (List<File>) -> Unit) {
        val files = selected.map { File(it) }.filter { it.exists() }
        if (files.isEmpty()) {
            toast(R.string.nothing_selected)
            return
        }
        exitSelection()
        action(files)
    }

    // ---------- Tarefas em segundo plano com indicador ----------

    private fun runTask(@StringRes msg: Int, work: () -> Int, done: (Int) -> Unit) {
        val label = TextView(this).apply {
            setText(msg)
            textSize = 16f
            setPadding(dp(16), 0, 0, 0)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(20), dp(24), dp(20))
            addView(ProgressBar(this@FileBrowserActivity))
            addView(label)
        }
        val dialog = AlertDialog.Builder(this).setView(box).setCancelable(false).create()
        dialog.show()
        executor.execute {
            val result = try { work() } catch (e: Exception) { 0 }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                if (dialog.isShowing) dialog.dismiss()
                done(result)
            }
        }
    }

    private fun toastCount(ok: Int, total: Int) {
        Toast.makeText(
            this,
            if (ok == total) getString(R.string.paste_done) else getString(R.string.paste_partial, ok, total),
            Toast.LENGTH_SHORT
        ).show()
    }

    // ---------- Nomes únicos / cópia / movimento ----------

    private fun uniqueDest(dir: File, name: String): File {
        val first = File(dir, name)
        if (!first.exists()) return first
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        var dest: File
        do {
            dest = File(dir, "$base ($i)$ext")
            i++
        } while (dest.exists())
        return dest
    }

    private fun moveFile(src: File, dest: File): Boolean {
        if (src.renameTo(dest)) return true
        return try {
            src.copyRecursively(dest, overwrite = false) && src.deleteRecursively()
        } catch (e: Exception) {
            dest.deleteRecursively()
            false
        }
    }

    private fun copyFile(src: File, dest: File): Boolean =
        try {
            src.copyRecursively(dest, overwrite = false)
        } catch (e: Exception) {
            dest.deleteRecursively()
            false
        }

    // ---------- Copiar / Mover (escolher a pasta de destino) ----------

    private fun startPaste(files: List<File>, move: Boolean) {
        pending = PendingOp(files, move)
        originalRoot = rootDir
        rootDir = Environment.getExternalStorageDirectory() // permite navegar para qualquer pasta
        moveText.text = when {
            move && files.size == 1 -> getString(R.string.moving, files[0].name)
            move -> getString(R.string.moving_many, files.size)
            files.size == 1 -> getString(R.string.copying, files[0].name)
            else -> getString(R.string.copying_many, files.size)
        }
        moveHereButton.setText(if (move) R.string.move_here else R.string.copy_here)
        moveBar.visibility = View.VISIBLE
        reload()
        if (Device.isTv(this)) moveHereButton.requestFocus()
    }

    private fun endPaste() {
        pending = null
        moveBar.visibility = View.GONE
        rootDir = originalRoot
        val root = rootDir
        val cur = currentDir
        if (root != null && cur != null && !cur.absolutePath.startsWith(root.absolutePath)) {
            loadDir(root)
        } else {
            reload()
        }
    }

    private fun confirmPaste() {
        val op = pending ?: return
        val dir = currentDir ?: return
        runTask(if (op.move) R.string.working_moving else R.string.working_copying, work = {
            var ok = 0
            op.files.forEach { src ->
                when {
                    op.move && src.parentFile == dir -> ok++ // já está nesta pasta
                    dir == src || dir.absolutePath.startsWith(src.absolutePath + "/") -> Unit // pasta dentro dela mesma
                    else -> {
                        val dest = uniqueDest(dir, src.name) // nunca sobrescreve
                        val done = if (op.move) moveFile(src, dest) else copyFile(src, dest)
                        if (done) ok++
                    }
                }
            }
            ok
        }, done = { ok ->
            toastCount(ok, op.files.size)
            endPaste()
        })
    }

    // ---------- Renomear ----------

    private fun showRename(file: File) {
        val input = EditText(this).apply {
            setText(file.name)
            setSelection(0, file.nameWithoutExtension.length)
            setSingleLine()
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.rename_title)
            .setView(box)
            .setPositiveButton(R.string.rename_ok) { _, _ ->
                val newName = input.text.toString().trim()
                when {
                    newName.isEmpty() || newName.contains('/') -> toast(R.string.rename_invalid)
                    newName == file.name -> Unit
                    else -> {
                        val dest = File(file.parentFile, newName)
                        when {
                            dest.exists() -> toast(R.string.name_exists)
                            file.renameTo(dest) -> { toast(R.string.rename_done); reload() }
                            else -> toast(R.string.rename_fail)
                        }
                    }
                }
            }
            .setNegativeButton(R.string.move_cancel, null)
            .show()
    }

    // ---------- Excluir (um ou vários) ----------

    private fun confirmDelete(files: List<File>) {
        val message = TextView(this).apply {
            text = if (files.size == 1) getString(R.string.delete_message, files[0].name)
            else getString(R.string.delete_message_many, files.size)
            textSize = 16f
        }
        val check = CheckBox(this).apply { setText(R.string.delete_permanent) }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(message)
            addView(check)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.delete_title)
            .setView(box)
            .setPositiveButton(R.string.delete_confirm) { _, _ -> deleteFiles(files, check.isChecked) }
            .setNegativeButton(R.string.move_cancel, null)
            .show()
        // Foco inicial em "Cancelar" para evitar exclusão acidental
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).requestFocus()
    }

    private fun deleteFiles(files: List<File>, permanentChoice: Boolean) {
        runTask(R.string.working_delete, work = {
            var ok = 0
            files.forEach { f ->
                val inTrash = f.absolutePath.startsWith(Trash.dir().absolutePath)
                val permanent = permanentChoice || inTrash
                val done = if (permanent) f.deleteRecursively() else moveToTrash(f)
                if (done) ok++
            }
            ok
        }, done = { ok ->
            when {
                ok == files.size -> toast(if (permanentChoice) R.string.deleted_perm else R.string.deleted_trash)
                ok == 0 -> toast(R.string.delete_fail)
                else -> toastCount(ok, files.size)
            }
            reload()
        })
    }

    private fun moveToTrash(file: File): Boolean {
        val trash = Trash.dir().also { it.mkdirs() }
        var dest = File(trash, file.name)
        if (dest.exists()) dest = File(trash, "${System.currentTimeMillis()}_${file.name}")
        return moveFile(file, dest)
    }

    // ---------- Compactar (ZIP ou APK) ----------

    private fun showCompress(files: List<File>) {
        val defaultName = if (files.size == 1) files[0].nameWithoutExtension.ifEmpty { files[0].name }
        else getString(R.string.compress_default_name)
        val input = EditText(this).apply {
            setText(defaultName)
            setSelectAllOnFocus(true)
            setSingleLine()
        }
        val apkCheck = CheckBox(this).apply { setText(R.string.compress_as_apk) }
        val hint = TextView(this).apply {
            setText(R.string.compress_apk_hint)
            textSize = 13f
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
            addView(apkCheck)
            addView(hint)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.compress_title)
            .setView(box)
            .setPositiveButton(R.string.compress_ok) { _, _ ->
                val name = input.text.toString().trim().removeSuffix(".zip").removeSuffix(".apk")
                val dir = currentDir
                if (name.isEmpty() || name.contains('/') || dir == null) {
                    toast(R.string.rename_invalid)
                    return@setPositiveButton
                }
                val out = uniqueDest(dir, name + if (apkCheck.isChecked) ".apk" else ".zip")
                runTask(R.string.working_compress, work = {
                    if (zipFiles(files, out)) 1 else { out.delete(); 0 }
                }, done = { ok ->
                    toast(if (ok == 1) R.string.compress_done else R.string.compress_fail)
                    reload()
                })
            }
            .setNegativeButton(R.string.move_cancel, null)
            .show()
    }

    private fun zipFiles(files: List<File>, out: File): Boolean {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            files.forEach { f -> addToZip(zos, f, f.parentFile ?: f) }
        }
        return true
    }

    private fun addToZip(zos: ZipOutputStream, f: File, base: File) {
        val name = f.relativeTo(base).path.replace(File.separatorChar, '/')
        if (f.isDirectory) {
            zos.putNextEntry(ZipEntry("$name/"))
            zos.closeEntry()
            f.listFiles()?.forEach { addToZip(zos, it, base) }
        } else {
            zos.putNextEntry(ZipEntry(name))
            f.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    // ---------- Extrair (ZIP e APK) ----------

    private fun extractHere(archive: File) {
        val target = archive.parentFile ?: return
        runExtract(archive, target)
    }

    private fun extractToFolder(archive: File) {
        val parent = archive.parentFile ?: return
        runExtract(archive, uniqueDest(parent, archive.nameWithoutExtension.ifEmpty { "extraido" }))
    }

    private fun runExtract(archive: File, target: File) {
        runTask(R.string.working_extract, work = {
            if (extractArchive(archive, target)) 1 else 0
        }, done = { ok ->
            toast(if (ok == 1) R.string.extract_done else R.string.extract_fail)
            reload()
        })
    }

    private fun extractArchive(archive: File, target: File): Boolean {
        target.mkdirs()
        val targetPath = target.canonicalPath
        ZipFile(archive).use { zf ->
            val entries = zf.entries()
            while (entries.hasMoreElements()) {
                val e = entries.nextElement()
                var dest = File(target, e.name)
                // Proteção contra caminhos maliciosos ("zip slip")
                val canon = dest.canonicalPath
                if (canon != targetPath && !canon.startsWith(targetPath + File.separator)) continue
                if (e.isDirectory) {
                    dest.mkdirs()
                    continue
                }
                val parent = dest.parentFile ?: continue
                parent.mkdirs()
                if (dest.exists()) dest = uniqueDest(parent, dest.name) // nunca sobrescreve
                zf.getInputStream(e).use { input ->
                    dest.outputStream().use { input.copyTo(it) }
                }
            }
        }
        return true
    }

    // ---------- Instalar APK ----------

    private fun confirmInstall(file: File) {
        val info = packageManager.getPackageArchiveInfo(file.absolutePath, 0)
        info?.applicationInfo?.let {
            it.sourceDir = file.absolutePath
            it.publicSourceDir = file.absolutePath
        }
        val label = info?.applicationInfo?.loadLabel(packageManager)?.toString() ?: file.name
        var message = getString(R.string.install_message, label)
        info?.versionName?.let { message += "\n\n" + getString(R.string.install_version, it) }

        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.install_title)
            .setMessage(message)
            .setPositiveButton(R.string.install_yes) { _, _ -> installApk(file) }
            .setNegativeButton(R.string.install_no, null)
            .show()
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).requestFocus()
    }

    private fun installApk(file: File) {
        // Android 8+: o usuário precisa permitir "instalar apps desconhecidos" para este app
        if (!packageManager.canRequestPackageInstalls()) {
            try {
                Toast.makeText(this, R.string.install_allow_hint, Toast.LENGTH_LONG).show()
                startActivity(
                    Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                toast(R.string.install_fail)
            }
            return
        }
        // Instalação por sessão (PackageInstaller): funciona mesmo em TVs sem o app instalador padrão.
        executor.execute {
            try {
                val installer = packageManager.packageInstaller
                val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                val id = installer.createSession(params)
                installer.openSession(id).use { session ->
                    file.inputStream().use { input ->
                        session.openWrite("app.apk", 0, file.length()).use { out ->
                            input.copyTo(out)
                            session.fsync(out)
                        }
                    }
                    val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                            (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                    val pi = PendingIntent.getBroadcast(
                        this, id, Intent(this, InstallReceiver::class.java), flags
                    )
                    session.commit(pi.intentSender)
                }
            } catch (e: Exception) {
                runOnUiThread { installWithViewer(file) }
            }
        }
    }

    /** Alternativa caso a sessão de instalação falhe. */
    private fun installWithViewer(file: File) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            startActivity(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/vnd.android.package-archive")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            )
        } catch (e: Exception) {
            toast(R.string.install_fail)
        }
    }

    // ---------- Opções de aplicativo (segurar em Aplicativos Instalados) ----------

    private fun showAppOptions(item: FileItem) {
        val pkg = item.path
        val options = arrayOf(
            getString(R.string.app_clear_data),
            getString(R.string.app_clear_cache),
            getString(R.string.app_uninstall)
        )
        AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openAppInfo(pkg, R.string.hint_clear_data)
                    1 -> openAppInfo(pkg, R.string.hint_clear_cache)
                    2 -> uninstallApp(pkg)
                }
            }
            .show()
    }

    /** Apps de terceiros não podem limpar dados/cache de outros apps; o Android só permite pela tela de informações. */
    private fun openAppInfo(pkg: String, hint: Int) {
        try {
            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
            Toast.makeText(this, hint, Toast.LENGTH_LONG).show()
            needsAppsRefresh = true
            startActivity(i)
        } catch (e: Exception) {
            toast(R.string.app_info_unavailable)
        }
    }

    private fun uninstallApp(pkg: String) {
        val info = try { packageManager.getApplicationInfo(pkg, 0) } catch (e: Exception) { null }
        val isSystem = info != null &&
                (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (info.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
        if (isSystem) {
            toast(R.string.app_system_no_uninstall)
            return
        }
        try {
            needsAppsRefresh = true
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))
        } catch (e: Exception) {
            toast(R.string.app_info_unavailable)
        }
    }

    // ---------- Abrir arquivo ----------

    private fun openFile(file: File) {
        val ext = MimeTypeMap.getFileExtensionFromUrl(file.name).lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(view)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show()
        }
    }
}

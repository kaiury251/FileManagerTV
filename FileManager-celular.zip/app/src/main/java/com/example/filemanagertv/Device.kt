package com.example.filemanagertv

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

/** Utilidades para adaptar a interface entre TV (D-Pad) e celular/tablet (toque). */
object Device {

    fun isTv(ctx: Context): Boolean {
        val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
                ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }

    fun widthDp(ctx: Context): Int = ctx.resources.configuration.screenWidthDp

    /** Colunas da grade inicial: 2 no celular em pé, 3 em tablet/celular deitado, até 4 na TV. */
    fun categorySpans(ctx: Context): Int = (widthDp(ctx) / 180).coerceIn(2, 4)

    /** Colunas do navegador de arquivos: 1 no celular em pé, até 3 na TV. */
    fun browserSpans(ctx: Context): Int = (widthDp(ctx) / 300).coerceIn(1, 3)
}

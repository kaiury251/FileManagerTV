package com.example.filemanagertv

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var grid: RecyclerView
    private lateinit var permissionButton: Button

    private val legacyPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { updateUi() }

    private val categories = listOf(
        Category(CategoryType.STORAGE, R.string.cat_storage, R.drawable.ic_storage),
        Category(CategoryType.DOWNLOADS, R.string.cat_downloads, R.drawable.ic_download),
        Category(CategoryType.IMAGES, R.string.cat_images, R.drawable.ic_image),
        Category(CategoryType.MUSIC, R.string.cat_music, R.drawable.ic_music),
        Category(CategoryType.VIDEOS, R.string.cat_videos, R.drawable.ic_video),
        Category(CategoryType.APPS, R.string.cat_apps, R.drawable.ic_apps)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.categoryGrid)
        permissionButton = findViewById(R.id.permissionButton)

        grid.layoutManager = GridLayoutManager(this, 3)
        grid.adapter = CategoryAdapter(categories) { openCategory(it) }
        permissionButton.setOnClickListener { requestStorageAccess() }
    }

    override fun onResume() {
        super.onResume()
        updateUi()
    }

    private fun updateUi() {
        val granted = hasStorageAccess()
        permissionButton.visibility = if (granted) View.GONE else View.VISIBLE
        if (granted) {
            // Foco inicial no primeiro card para o D-Pad funcionar de imediato.
            grid.post { grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        } else {
            permissionButton.requestFocus()
        }
    }

    private fun hasStorageAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        }

    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                } catch (e2: Exception) {
                    // Algumas TVs não têm essa tela de configurações.
                    Toast.makeText(this, R.string.permission_adb_hint, Toast.LENGTH_LONG).show()
                }
            }
        } else {
            legacyPermission.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun openCategory(category: Category) {
        if (!hasStorageAccess() && category.type != CategoryType.APPS) {
            requestStorageAccess()
            return
        }
        val intent = Intent(this, FileBrowserActivity::class.java)
        intent.putExtra(FileBrowserActivity.EXTRA_TITLE, getString(category.title))
        when (category.type) {
            CategoryType.APPS -> intent.putExtra(FileBrowserActivity.EXTRA_APPS, true)
            CategoryType.STORAGE -> intent.putExtra(
                FileBrowserActivity.EXTRA_PATH, Environment.getExternalStorageDirectory().absolutePath
            )
            CategoryType.DOWNLOADS -> intent.putExtra(FileBrowserActivity.EXTRA_PATH, publicDir(Environment.DIRECTORY_DOWNLOADS))
            CategoryType.IMAGES -> intent.putExtra(FileBrowserActivity.EXTRA_PATH, publicDir(Environment.DIRECTORY_PICTURES))
            CategoryType.MUSIC -> intent.putExtra(FileBrowserActivity.EXTRA_PATH, publicDir(Environment.DIRECTORY_MUSIC))
            CategoryType.VIDEOS -> intent.putExtra(FileBrowserActivity.EXTRA_PATH, publicDir(Environment.DIRECTORY_MOVIES))
        }
        startActivity(intent)
    }

    private fun publicDir(type: String): String =
        Environment.getExternalStoragePublicDirectory(type).absolutePath
}

# Code Downloader (Android TV + Mobile)

Kotlin + Jetpack Compose (Material3), dark mode, tela única.

## Arquitetura
- UrlResolver: monta https://aftv.news/<código> e segue 301/302/303/307/308 manualmente até a URL final.
- Downloader: OkHttp em streaming, grava em .part, calcula % e MB/s, cancelável por coroutine.
- HistoryStore: últimos 5 downloads (SharedPreferences/JSON).
- Installer: se .apk, pede "fontes desconhecidas" e abre o instalador via FileProvider.
- MainViewModel: StateFlow (código, UiState, histórico) e orquestração.
- ui/: tema, FocusButton (borda neon no foco), teclado numérico, histórico, diálogo de progresso.

## Notas
- Arquivos vão para getExternalFilesDir(DIRECTORY_DOWNLOADS): sem permissão de armazenamento (apagados ao desinstalar o app).
- Teclado físico também digita letras e números (código alfanumérico).
- Adicione um banner 320x180 e troque android:banner para a TV ficar polida.
- Abrir no Android Studio, sincronizar o Gradle e rodar.

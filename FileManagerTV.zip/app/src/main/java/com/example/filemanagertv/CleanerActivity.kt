package com.example.filemanagertv

import android.os.Bundle
import android.os.Environment
import android.text.format.Formatter
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class CleanerActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var totalText: TextView
    private lateinit var cleanButton: Button
    private lateinit var rescanButton: Button
    private lateinit var adapter: CleanerAdapter
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cleaner)

        list = findViewById(R.id.junkList)
        totalText = findViewById(R.id.totalText)
        cleanButton = findViewById(R.id.cleanButton)
        rescanButton = findViewById(R.id.rescanButton)

        adapter = CleanerAdapter { updateTotal() }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        cleanButton.setOnClickListener { confirmClean() }
        rescanButton.setOnClickListener { scan() }
        scan()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun setBusy(busy: Boolean) {
        cleanButton.isEnabled = !busy
        rescanButton.isEnabled = !busy
        if (busy) totalText.setText(R.string.cleaner_scanning)
    }

    private fun scan() {
        setBusy(true)
        executor.execute {
            val groups = JunkScanner.scan(
                Environment.getExternalStorageDirectory(),
                listOfNotNull(cacheDir, externalCacheDir)
            )
            runOnUiThread {
                adapter.submit(groups)
                setBusy(false)
                updateTotal()
                list.post { list.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
            }
        }
    }

    private fun updateTotal() {
        totalText.text = getString(
            R.string.cleaner_total, Formatter.formatShortFileSize(this, adapter.selectedBytes())
        )
    }

    private fun confirmClean() {
        val groups = adapter.selectedGroups()
        if (groups.isEmpty()) {
            Toast.makeText(this, R.string.cleaner_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        val size = Formatter.formatShortFileSize(this, adapter.selectedBytes())
        AlertDialog.Builder(this)
            .setTitle(R.string.cleaner_confirm_title)
            .setMessage(getString(R.string.cleaner_confirm_msg, size))
            .setPositiveButton(R.string.cleaner_confirm_yes) { _, _ -> clean(groups) }
            .setNegativeButton(R.string.cleaner_confirm_no, null)
            .show()
    }

    private fun clean(groups: List<JunkGroup>) {
        setBusy(true)
        executor.execute {
            val freed = groups.sumOf { JunkScanner.delete(it) }
            runOnUiThread {
                Toast.makeText(
                    this, getString(R.string.cleaner_done, Formatter.formatShortFileSize(this, freed)),
                    Toast.LENGTH_LONG
                ).show()
                scan()
            }
        }
    }
}

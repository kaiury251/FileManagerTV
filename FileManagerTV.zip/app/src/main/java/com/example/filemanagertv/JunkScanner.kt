package com.example.filemanagertv

import androidx.annotation.StringRes
import java.io.File

enum class JunkType(@StringRes val title: Int, @StringRes val desc: Int) {
    CACHE(R.string.junk_cache, R.string.junk_cache_desc),
    TEMP(R.string.junk_temp, R.string.junk_temp_desc),
    THUMBS(R.string.junk_thumbs, R.string.junk_thumbs_desc),
    APKS(R.string.junk_apks, R.string.junk_apks_desc),
    EMPTY(R.string.junk_empty, R.string.junk_empty_desc)
}

class JunkGroup(val type: JunkType) {
    val files = mutableListOf<File>()
    var size = 0L
    var checked = true
}

object JunkScanner {

    private val TEMP_EXT = setOf(
        "tmp", "temp", "log", "bak", "old", "chk", "crdownload", "part", "partial", "download"
    )

    /** Varre o armazenamento e agrupa o que pode ser limpo. Rodar fora da thread principal. */
    fun scan(root: File, ownCaches: List<File>): List<JunkGroup> {
        val groups = JunkType.values().associateWith { JunkGroup(it) }

        // Cache do próprio app
        ownCaches.filter { it.exists() }.forEach { groups.getValue(JunkType.CACHE).files.add(it) }

        // Cache de outros apps (em Android 11+ o acesso a Android/data pode ser bloqueado)
        File(root, "Android/data").listFiles()?.forEach { app ->
            val cache = File(app, "cache")
            if (cache.isDirectory && !cache.list().isNullOrEmpty()) {
                groups.getValue(JunkType.CACHE).files.add(cache)
            }
        }

        val androidDir = File(root, "Android")
        root.walkTopDown()
            .onEnter { dir ->
                when {
                    dir == androidDir -> false // já tratado acima
                    dir.name == ".thumbnails" -> {
                        groups.getValue(JunkType.THUMBS).files.add(dir)
                        false
                    }
                    else -> {
                        if (dir != root && dir.list()?.isEmpty() == true) {
                            groups.getValue(JunkType.EMPTY).files.add(dir)
                        }
                        true
                    }
                }
            }
            .filter { it.isFile }
            .forEach { f ->
                val ext = f.extension.lowercase()
                when {
                    ext == "apk" -> groups.getValue(JunkType.APKS).files.add(f)
                    ext in TEMP_EXT -> groups.getValue(JunkType.TEMP).files.add(f)
                }
            }

        groups.values.forEach { g -> g.size = g.files.sumOf { sizeOf(it) } }
        return groups.values.toList()
    }

    fun delete(group: JunkGroup): Long {
        var freed = 0L
        group.files.forEach { f ->
            val s = sizeOf(f)
            val ok = if (group.type == JunkType.CACHE) {
                // Cache: apaga o conteúdo e mantém a pasta
                f.listFiles()?.map { it.deleteRecursively() }?.all { it } ?: true
            } else f.deleteRecursively()
            if (ok) freed += s
        }
        return freed
    }

    fun sizeOf(f: File): Long =
        if (f.isFile) f.length() else f.walkTopDown().filter { it.isFile }.sumOf { it.length() }
}

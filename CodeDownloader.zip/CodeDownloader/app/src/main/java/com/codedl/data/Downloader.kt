package com.codedl.data

import android.net.Uri
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException

class Downloader(private val client: OkHttpClient, private val dir: File) {

    /** onProgress(nome, baixado, total (-1 se desconhecido), MB/s). Cancelável via cancelamento da coroutine. */
    suspend fun download(
        url: String,
        fallbackName: String,
        onProgress: (String, Long, Long, Double) -> Unit
    ): File = withContext(Dispatchers.IO) {
        dir.mkdirs()
        val call = client.newCall(Request.Builder().url(url).build())
        coroutineScope {
            val watcher = launch { try { awaitCancellation() } finally { call.cancel() } }
            try {
                call.execute().use { resp ->
                    if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}")
                    val name = fileName(resp.header("Content-Disposition"), resp.request.url.pathSegments.lastOrNull(), fallbackName)
                    val total = resp.body!!.contentLength()
                    val part = File(dir, "$name.part")
                    val out = File(dir, name)
                    var done = 0L
                    var lastT = System.nanoTime(); var lastB = 0L; var speed = 0.0
                    resp.body!!.byteStream().use { input ->
                        part.outputStream().use { os ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                ensureActive()
                                val n = input.read(buf)
                                if (n < 0) break
                                os.write(buf, 0, n); done += n
                                val now = System.nanoTime()
                                if (now - lastT >= 500_000_000L) {
                                    speed = (done - lastB) / 1_048_576.0 / ((now - lastT) / 1e9)
                                    lastT = now; lastB = done
                                    onProgress(name, done, total, speed)
                                }
                            }
                        }
                    }
                    if (out.exists()) out.delete()
                    part.renameTo(out)
                    onProgress(name, done, total, speed)
                    out
                }
            } finally {
                watcher.cancel()
            }
        }
    }

    private fun fileName(disposition: String?, lastSegment: String?, fallback: String): String {
        val fromHeader = disposition?.let { Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?").find(it)?.groupValues?.get(1) }
        val raw = fromHeader ?: lastSegment?.takeIf { it.contains('.') } ?: fallback
        return Uri.decode(raw).replace(Regex("[\\\\/:*?\"<>|]"), "_")
    }
}

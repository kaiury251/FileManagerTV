package com.example.filemanagertv

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Environment
import android.os.StatFs
import java.io.File

object StorageInfo {

    /** Retorna (total, livre) em bytes do armazenamento interno. */
    fun totals(): Pair<Long, Long> {
        val st = StatFs(Environment.getExternalStorageDirectory().absolutePath)
        return st.totalBytes to st.availableBytes
    }

    /**
     * Soma o tamanho dos APKs dos aplicativos instalados pelo usuário (apps do sistema ficam em
     * outra partição e não entram na conta). Dados dos apps entram em "Outros".
     */
    fun appsBytes(pm: PackageManager): Long {
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(launcher, 0))
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter {
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                        (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            }
            .sumOf { ai ->
                val paths = listOfNotNull(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
                paths.sumOf { File(it).length() }
            }
    }
}

package com.example.filemanagertv

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class FileBrowserActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_TITLE = "title"
        const val EXTRA_APPS = "apps"
        private const val GRID_SPANS = 3
    }

    private lateinit var recycler: RecyclerView
    private lateinit var layoutManager: GridLayoutManager
    private lateinit var pathText: TextView
    private lateinit var emptyText: TextView
    private lateinit var toggleButton: Button
    private lateinit var upButton: Button
    private lateinit var adapter: FileAdapter

    private var rootDir: File? = null
    private var currentDir: File? = null
    private var gridMode = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_file_browser)

        recycler = findViewById(R.id.fileList)
        pathText = findViewById(R.id.pathText)
        emptyText = findViewById(R.id.emptyText)
        toggleButton = findViewById(R.id.toggleButton)
        upButton = findViewById(R.id.upButton)

        adapter = FileAdapter { onItemClick(it) }
        layoutManager = GridLayoutManager(this, GRID_SPANS)
        recycler.layoutManager = layoutManager
        recycler.adapter = adapter

        toggleButton.setOnClickListener { toggleMode() }
        upButton.setOnClickListener { goUp() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!goUp()) finish()
            }
        })

        if (intent.getBooleanExtra(EXTRA_APPS, false)) {
            pathText.text = intent.getStringExtra(EXTRA_TITLE)
            upButton.visibility = View.GONE
            loadApps()
        } else {
            val path = intent.getStringExtra(EXTRA_PATH) ?: "/sdcard"
            rootDir = File(path).also { if (!it.exists()) it.mkdirs() }
            loadDir(rootDir!!)
        }
    }

    private fun toggleMode() {
        gridMode = !gridMode
        layoutManager.spanCount = if (gridMode) GRID_SPANS else 1
        toggleButton.setText(if (gridMode) R.string.view_list else R.string.view_grid)
        adapter.notifyItemRangeChanged(0, adapter.itemCount)
    }

    private fun loadDir(dir: File) {
        currentDir = dir
        pathText.text = dir.absolutePath
        val files = dir.listFiles()?.sortedWith(
            compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() }
        ) ?: emptyList()

        val items = files.map {
            FileItem(it.name, it.absolutePath, it.isDirectory, if (it.isFile) it.length() else 0L, it.lastModified())
        }
        adapter.submitList(items) {
            emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            recycler.scrollToPosition(0)
            recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
        upButton.isEnabled = currentDir != rootDir
    }

    private fun goUp(): Boolean {
        val cur = currentDir ?: return false
        val root = rootDir ?: return false
        if (cur == root) return false
        cur.parentFile?.let { loadDir(it); return true }
        return false
    }

    private fun loadApps() {
        val pm = packageManager
        val leanback = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val all = (pm.queryIntentActivities(leanback, 0) + pm.queryIntentActivities(launcher, 0))
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val items = all.map {
            FileItem(
                name = it.loadLabel(pm).toString(),
                path = it.activityInfo.packageName,
                isDirectory = false,
                isApp = true,
                appIcon = it.loadIcon(pm)
            )
        }
        adapter.submitList(items) {
            emptyText.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            recycler.post { recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
        }
    }

    private fun onItemClick(item: FileItem) {
        when {
            item.isApp -> {
                val launch = packageManager.getLeanbackLaunchIntentForPackage(item.path)
                    ?: packageManager.getLaunchIntentForPackage(item.path)
                if (launch != null) startActivity(launch)
            }
            item.isDirectory -> loadDir(File(item.path))
            else -> openFile(File(item.path))
        }
    }

    private fun openFile(file: File) {
        val ext = MimeTypeMap.getFileExtensionFromUrl(file.name).lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val view = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(view)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show()
        }
    }
}

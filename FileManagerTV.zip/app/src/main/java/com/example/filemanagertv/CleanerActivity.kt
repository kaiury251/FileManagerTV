package com.example.filemanagertv

import android.os.Bundle
import android.os.Environment
import android.graphics.drawable.GradientDrawable
import android.text.format.Formatter
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class CleanerActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var totalText: TextView
    private lateinit var infoText: TextView
    private lateinit var emptyText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var cleanButton: Button
    private lateinit var rescanButton: Button
    private lateinit var adapter: CleanerAdapter
    private lateinit var storageUsedText: TextView
    private lateinit var storageFreeText: TextView
    private lateinit var storageBar: StorageBarView
    private lateinit var legendRow: LinearLayout
    private val legendSizes = mutableListOf<TextView>()
    private val executor = Executors.newSingleThreadExecutor()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cleaner)

        list = findViewById(R.id.junkList)
        totalText = findViewById(R.id.totalText)
        infoText = findViewById(R.id.infoText)
        emptyText = findViewById(R.id.emptyText)
        progress = findViewById(R.id.progress)
        cleanButton = findViewById(R.id.cleanButton)
        rescanButton = findViewById(R.id.rescanButton)
        storageUsedText = findViewById(R.id.storageUsedText)
        storageFreeText = findViewById(R.id.storageFreeText)
        storageBar = findViewById(R.id.storageBar)
        legendRow = findViewById(R.id.legendRow)
        buildLegend()
        updateStorage(null)

        adapter = CleanerAdapter(onChanged = { updateTotal() }, onDetails = { showDetails(it) })
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        cleanButton.setOnClickListener { confirmClean() }
        rescanButton.setOnClickListener { scan() }
        scan()
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }

    private fun setBusy(busy: Boolean) {
        cleanButton.isEnabled = !busy
        rescanButton.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) totalText.setText(R.string.cleaner_scanning)
    }

    private fun scan() {
        setBusy(true)
        emptyText.visibility = View.GONE
        executor.execute {
            val result = try {
                JunkScanner.scan(
                    Environment.getExternalStorageDirectory(),
                    listOfNotNull(cacheDir, externalCacheDir),
                    StorageInfo.appsBytes(packageManager)
                )
            } catch (e: Exception) {
                null
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                setBusy(false)
                if (result == null) {
                    adapter.submit(emptyList())
                    totalText.setText(R.string.cleaner_error)
                    cleanButton.isEnabled = false
                    return@runOnUiThread
                }
                updateStorage(result.breakdown)
                adapter.submit(result.groups)
                infoText.visibility = if (result.otherAppsCacheBlocked) View.VISIBLE else View.GONE
                emptyText.visibility = if (result.groups.isEmpty()) View.VISIBLE else View.GONE
                cleanButton.isEnabled = result.groups.isNotEmpty()
                updateTotal()
                list.post {
                    val first = list.findViewHolderForAdapterPosition(0)?.itemView
                    (first ?: rescanButton).requestFocus()
                }
            }
        }
    }

    // ---------- Barra de armazenamento ----------

    private val legendItems = listOf(
        R.string.legend_images to R.color.seg_images,
        R.string.legend_music to R.color.seg_music,
        R.string.legend_videos to R.color.seg_videos,
        R.string.legend_apps to R.color.seg_apps,
        R.string.legend_other to R.color.seg_other,
        R.string.legend_free to R.color.seg_free
    )

    private fun buildLegend() {
        legendItems.forEach { (name, color) ->
            val item = layoutInflater.inflate(R.layout.item_legend, legendRow, false)
            item.findViewById<TextView>(R.id.legendName).setText(name)
            val dot = item.findViewById<View>(R.id.legendDot)
            (dot.background.mutate() as GradientDrawable).setColor(ContextCompat.getColor(this, color))
            legendSizes.add(item.findViewById(R.id.legendSize))
            legendRow.addView(item)
        }
    }

    /** breakdown == null: ainda analisando, mostra só usado x livre. */
    private fun updateStorage(b: StorageBreakdown?) {
        val (total, free) = try { StorageInfo.totals() } catch (e: Exception) { 0L to 0L }
        val used = (total - free).coerceAtLeast(0L)
        val images = b?.images ?: 0L
        val music = b?.audio ?: 0L
        val videos = b?.video ?: 0L
        val apps = b?.apps ?: 0L
        val other = (used - images - music - videos - apps).coerceAtLeast(0L)

        storageUsedText.text = getString(
            R.string.storage_used_of, Formatter.formatShortFileSize(this, used), Formatter.formatShortFileSize(this, total)
        )
        storageFreeText.text = getString(R.string.storage_free, Formatter.formatShortFileSize(this, free))

        val values = listOf(images, music, videos, apps, other, free)
        storageBar.setSegments(
            values.mapIndexed { i, v ->
                StorageBarView.Segment(v, ContextCompat.getColor(this, legendItems[i].second))
            }
        )
        values.forEachIndexed { i, v ->
            // Enquanto analisa, só "Livre" tem valor confiável
            legendSizes[i].text =
                if (b == null && i != 5) "…" else Formatter.formatShortFileSize(this, v)
        }
    }

    private fun updateTotal() {
        totalText.text = getString(
            R.string.cleaner_total, Formatter.formatShortFileSize(this, adapter.selectedBytes())
        )
    }

    /** Lista os maiores itens da categoria (segurar OK). */
    private fun showDetails(g: JunkGroup) {
        val max = 40
        val sorted = g.files.sortedByDescending { g.itemSizes[it] ?: 0L }
        val labels = sorted.take(max).map {
            it.name + "  •  " + Formatter.formatShortFileSize(this, g.itemSizes[it] ?: 0L) +
                    "\n" + (it.parent ?: "")
        }.toMutableList()
        if (sorted.size > max) labels.add(getString(R.string.details_more, sorted.size - max))

        AlertDialog.Builder(this)
            .setTitle(getString(g.type.title) + " (" + sorted.size + ")")
            .setItems(labels.toTypedArray(), null)
            .setPositiveButton(R.string.details_close, null)
            .show()
    }

    private fun confirmClean() {
        val groups = adapter.selectedGroups()
        if (groups.isEmpty()) {
            Toast.makeText(this, R.string.cleaner_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        val size = Formatter.formatShortFileSize(this, adapter.selectedBytes())
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.cleaner_confirm_title)
            .setMessage(getString(R.string.cleaner_confirm_msg, size))
            .setPositiveButton(R.string.cleaner_confirm_yes) { _, _ -> clean(groups) }
            .setNegativeButton(R.string.cleaner_confirm_no, null)
            .show()
        // Foco inicial em "Cancelar" para evitar limpeza acidental
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).requestFocus()
    }

    private fun clean(groups: List<JunkGroup>) {
        setBusy(true)
        executor.execute {
            val freed = try { groups.sumOf { JunkScanner.delete(it) } } catch (e: Exception) { 0L }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                Toast.makeText(
                    this, getString(R.string.cleaner_done, Formatter.formatShortFileSize(this, freed)),
                    Toast.LENGTH_LONG
                ).show()
                scan()
            }
        }
    }
}

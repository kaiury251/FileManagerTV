package com.codedl.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class NotFoundException : Exception()

/** Segue manualmente a cadeia de redirects de https://aftv.news/<código> até a URL final. */
class UrlResolver(base: OkHttpClient) {
    private val client = base.newBuilder().followRedirects(false).followSslRedirects(false).build()

    suspend fun resolve(code: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            var url = "https://aftv.news/${code.trim()}"
            var hops = 0
            while (hops++ < 10) {
                val req = Request.Builder().url(url).get().build()
                client.newCall(req).execute().use { resp ->
                    when {
                        resp.code in listOf(301, 302, 303, 307, 308) -> {
                            val loc = resp.header("Location") ?: throw NotFoundException()
                            url = resp.request.url.resolve(loc)?.toString() ?: throw NotFoundException()
                        }
                        resp.isSuccessful -> {
                            val type = resp.header("Content-Type").orEmpty()
                            if (hops == 1 && type.startsWith("text/html")) throw NotFoundException()
                            return@withContext Result.success(url)
                        }
                        else -> throw NotFoundException()
                    }
                }
            }
            Result.failure(NotFoundException())
        } catch (e: IOException) {
            Result.failure(e)
        } catch (e: NotFoundException) {
            Result.failure(e)
        }
    }
}

package com.example.filemanagertv

import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.util.Date

class FileAdapter(
    private val onClick: (FileItem) -> Unit,
    private val onLongClick: (FileItem) -> Unit
) : ListAdapter<FileItem, FileAdapter.VH>(Diff) {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.fileIcon)
        val name: TextView = view.findViewById(R.id.fileName)
        val info: TextView = view.findViewById(R.id.fileInfo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = getItem(position)
        val ctx = holder.itemView.context
        holder.name.text = item.name

        when {
            item.isApp && item.appIcon != null -> {
                holder.icon.clearColorFilter()
                holder.icon.setImageDrawable(item.appIcon)
                holder.info.text = item.path
            }
            item.isDirectory -> {
                holder.icon.setImageResource(R.drawable.ic_folder)
                holder.info.text = DateFormat.getMediumDateFormat(ctx).format(Date(item.modified))
            }
            else -> {
                holder.icon.setImageResource(R.drawable.ic_file)
                holder.info.text = Formatter.formatShortFileSize(ctx, item.size) + "  •  " +
                        DateFormat.getMediumDateFormat(ctx).format(Date(item.modified))
            }
        }

        holder.itemView.setOnClickListener { onClick(item) }
        // Segurar OK no controle remoto dispara o clique longo
        holder.itemView.setOnLongClickListener { onLongClick(item); true }
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val s = if (hasFocus) 1.04f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(100).start()
        }
    }

    object Diff : DiffUtil.ItemCallback<FileItem>() {
        override fun areItemsTheSame(a: FileItem, b: FileItem) = a.path == b.path
        override fun areContentsTheSame(a: FileItem, b: FileItem) =
            a.name == b.name && a.size == b.size && a.modified == b.modified
    }
}

package com.example.filemanagertv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter da grade inicial. Cada card é focável pelo D-Pad; o destaque visual
 * vem do card_selector.xml (borda/cor) + animação de escala ao receber foco.
 */
class CategoryAdapter(
    private val items: List<Category>,
    private val onClick: (Category) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.categoryIcon)
        val title: TextView = view.findViewById(R.id.categoryTitle)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.icon.setImageResource(item.icon)
        holder.title.setText(item.title)

        holder.itemView.setOnClickListener { onClick(item) }
        // Também aceita OK/Enter do controle (já tratado pelo clique em views focáveis).
        holder.itemView.setOnFocusChangeListener { v, hasFocus ->
            val scale = if (hasFocus) 1.08f else 1.0f
            v.animate().scaleX(scale).scaleY(scale).setDuration(120).start()
            v.elevation = if (hasFocus) 16f else 2f
        }
    }

    override fun getItemCount() = items.size
}
